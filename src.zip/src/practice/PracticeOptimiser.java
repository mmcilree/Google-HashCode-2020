package practice;

import common.Optimiser;
import common.TabularData;

import java.util.ArrayList;

/**
 * This is an example of how we might override the optimiser for the 2020 practice problem.
 */
public class PracticeOptimiser implements Optimiser {
    private int maxSlices;
    private int pizzaKinds;
    private ArrayList<Integer> sliceNumbers;
    TabularData output = new TabularData();

    @Override
    public TabularData optimise(TabularData inputData) {
        init(inputData);
        dumbSolution();
        return output;
    }

    private void init(TabularData inputData) {
        maxSlices = inputData.getElementAsInt(0, 0);
        pizzaKinds = inputData.getElementAsInt(0, 0);
        sliceNumbers = inputData.getRowAsIntList(1);

    }

    private void dumbSolution() {
        output.clear();
        int slicesLeft = maxSlices;
        int kindCount = 0;
        ArrayList<String> kindList = new ArrayList<>();

        for(int i = sliceNumbers.size() - 1; i >= 0; i--) {
            System.out.println(slicesLeft);
            slicesLeft -= sliceNumbers.get(i);
            if(slicesLeft < 0) {
                break;
            }
            kindList.add("" + kindCount);
            kindCount++;
        }

        ArrayList<String> line1 = new ArrayList<>();
        line1.add("" + kindCount);

        output.addRow(line1);
        output.addRow(kindList);
    }
}
